/*
 * epfas.h
 *
 *  Created on: Jan 19, 2025
 *      Author: Alexey
 */

#ifndef INC_EPFAS_H_
#define INC_EPFAS_H_

#define SYMBOL_COUNT 3

void EPFAS_SysInit();
void EPFAS_SysNextMode();
void EPFAS_SysCounterInc();
void EPFAS_SysCounterStepDown();
int unsigned EPFAS_GetCounter();
char EPFAS_GetMode();

#endif /* INC_EPFAS_H_ */
