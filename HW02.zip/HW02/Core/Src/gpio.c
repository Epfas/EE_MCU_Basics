/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    gpio.c
  * @brief   This file provides code for the configuration
  *          of all used GPIO pins.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "gpio.h"

/* USER CODE BEGIN 0 */
#include "epfas.h"
/* USER CODE END 0 */

/*----------------------------------------------------------------------------*/
/* Configure GPIO                                                             */
/*----------------------------------------------------------------------------*/
/* USER CODE BEGIN 1 */

uint16_t symbolPins[SYMBOL_COUNT];
GPIO_TypeDef* symbolPorts[SYMBOL_COUNT];

/* USER CODE END 1 */

/** Configure pins as
        * Analog
        * Input
        * Output
        * EVENT_OUT
        * EXTI
        * Free pins are configured automatically as Analog (this feature is enabled through
        * the Code Generation settings)
*/
void MX_GPIO_Init(void)
{

  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, DS_Pin|STCP_Pin|SHCP_Pin|Digit_1_Pin
                          |Digit_2_Pin|Digit_3_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, LED_A_Pin|LED_B_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pins : PC13 PC14 PC15 */
  GPIO_InitStruct.Pin = GPIO_PIN_13|GPIO_PIN_14|GPIO_PIN_15;
  GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : PH0 PH1 */
  GPIO_InitStruct.Pin = GPIO_PIN_0|GPIO_PIN_1;
  GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOH, &GPIO_InitStruct);

  /*Configure GPIO pins : PA0 PA4 PA5 PA8
                           PA9 PA15 */
  GPIO_InitStruct.Pin = GPIO_PIN_0|GPIO_PIN_4|GPIO_PIN_5|GPIO_PIN_8
                          |GPIO_PIN_9|GPIO_PIN_15;
  GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : DS_Pin STCP_Pin SHCP_Pin Digit_1_Pin
                           Digit_2_Pin Digit_3_Pin */
  GPIO_InitStruct.Pin = DS_Pin|STCP_Pin|SHCP_Pin|Digit_1_Pin
                          |Digit_2_Pin|Digit_3_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : Btn_A_Pin Btn_B_Pin */
  GPIO_InitStruct.Pin = Btn_A_Pin|Btn_B_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : PB0 PB10 PB12 PB13
                           PB14 PB15 PB3 PB4
                           PB5 PB6 PB7 PB8
                           PB9 */
  GPIO_InitStruct.Pin = GPIO_PIN_0|GPIO_PIN_10|GPIO_PIN_12|GPIO_PIN_13
                          |GPIO_PIN_14|GPIO_PIN_15|GPIO_PIN_3|GPIO_PIN_4
                          |GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7|GPIO_PIN_8
                          |GPIO_PIN_9;
  GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pins : LED_A_Pin LED_B_Pin */
  GPIO_InitStruct.Pin = LED_A_Pin|LED_B_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI9_5_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI9_5_IRQn);

}

/* USER CODE BEGIN 2 */

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
  switch (GPIO_Pin)
  {
    case Btn_A_Pin:
      EPFAS_SysNextMode();
      break;

    case Btn_B_Pin:
      EPFAS_SysCounterInc();
      break;
  }
}

void EPFAS_GPIO_Init()
{
  EPFAS_SymbolPinInit(0U, Digit_1_GPIO_Port, Digit_1_Pin);
  EPFAS_SymbolPinInit(1U, Digit_2_GPIO_Port, Digit_2_Pin);
  EPFAS_SymbolPinInit(2U, Digit_3_GPIO_Port, Digit_3_Pin);
  EPFAS_SysInit();
}

void EPFAS_SymbolPinInit(uint8_t symbolPosition, GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin)
{
  if (symbolPosition >= SYMBOL_COUNT)
    return;
  symbolPorts[symbolPosition] = GPIOx;
  symbolPins[symbolPosition] = GPIO_Pin;
}

void EPFAS_SymbolPinWrite(uint8_t symbolPosition, FlagStatus state)
{
  if (symbolPosition >= SYMBOL_COUNT || !symbolPins[symbolPosition])
    return;
  HAL_GPIO_WritePin(symbolPorts[symbolPosition], symbolPins[symbolPosition], state);
}

void EPFAS_SymbolsSetOff()
{
  for (uint8_t i = 0; i < SYMBOL_COUNT; i++)
    EPFAS_SymbolPinWrite(i, RESET);
}

char EPFAS_EncodeDigitToSymbol(char digit)
{
  switch (digit)
  {
    case 0:
      return 4+8+16+32+64+128;
    case 1:
      return 32+64;
    case 2:
      return 1+8+16+64+128;
    case 3:
      return 1+16+32+64+128;
    case 4:
      return 1+4+32+64;
    case 5:
      return 1+4+16+32+128;
    case 6:
      return 1+4+8+16+32+128;;
    case 7:
      return 32+64+128;
    case 8:
      return 1+4+8+16+32+64+128;
    case 9:
      return 1+4+16+32+64+128;
  }
  return 0;
}

void EPFAS_SendSymbol(uint8_t symbolPosition, char symbol)
{
  EPFAS_SymbolsSetOff();
  if (!symbol)
    return;

  HAL_GPIO_WritePin(SHCP_GPIO_Port, SHCP_Pin, RESET);
  HAL_GPIO_WritePin(STCP_GPIO_Port, STCP_Pin, RESET);

  for (uint8_t i = 0; i < 8; i++)
  {
    if (symbol % 2) {
      HAL_GPIO_WritePin(DS_GPIO_Port, DS_Pin, SET);
    } else {
      HAL_GPIO_WritePin(DS_GPIO_Port, DS_Pin, RESET);
    }
    HAL_GPIO_WritePin(STCP_GPIO_Port, STCP_Pin, SET);
    HAL_GPIO_WritePin(STCP_GPIO_Port, STCP_Pin, RESET);
    symbol = symbol / 2U;
  }

  HAL_GPIO_WritePin(SHCP_GPIO_Port, SHCP_Pin, SET);
  HAL_GPIO_WritePin(SHCP_GPIO_Port, SHCP_Pin, RESET);
  HAL_GPIO_WritePin(DS_GPIO_Port, DS_Pin, RESET);

  EPFAS_SymbolPinWrite(symbolPosition, SET);
}

void EPFAS_ShowCounter(char dark)
{
  static uint8_t currPosition = 0;
  static uint16_t denominator = 1;
  char symbol;

  if ((EPFAS_GetMode() == currPosition + 1) && dark)
  {
    symbol = 0;
  } else {
    symbol = EPFAS_GetCounter() / denominator % 10;
    symbol = EPFAS_EncodeDigitToSymbol(symbol);
  }
  EPFAS_SendSymbol(SYMBOL_COUNT - currPosition -1, symbol);

  currPosition++;
  denominator *= 10;
  if (currPosition >= SYMBOL_COUNT)
  {
    currPosition = 0;
    denominator = 1;
  }
}

void EPFAS_ShowTick(uint32_t tick)
{
  static uint8_t currPosition = 0;
  static uint16_t denominator = 1;
  char symbol;

  symbol = tick / denominator % 10;
  symbol = EPFAS_EncodeDigitToSymbol(symbol);

  EPFAS_SendSymbol(SYMBOL_COUNT - currPosition -1, symbol);

  currPosition++;
  denominator *= 10;
  if (currPosition >= SYMBOL_COUNT)
  {
    currPosition = 0;
    denominator = 1;
  }
}


void EPFAS_UpdateIndicators(uint32_t tick)
{
  static uint32_t lastTick = 0;
  if (tick - lastTick < 7)
    return;

  lastTick = tick;
  char dark = (tick % 1000) < 300;
  EPFAS_ShowCounter(dark);
  // EPFAS_ShowTick(tick);
}

void EPFAS_CountDown(uint32_t tick)
{
  static uint32_t lastTick = 0;

  if (EPFAS_GetMode() || (tick - lastTick < 1000))
    return;

  lastTick = tick;
  EPFAS_SysCounterStepDown();
}

/* USER CODE END 2 */
