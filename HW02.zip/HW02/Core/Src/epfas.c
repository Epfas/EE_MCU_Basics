/*
 * epfas.c
 *
 *  Created on: Jan 19, 2025
 *      Author: EPFAS
 */
#include "epfas.h"

int unsigned volatile counter;
char volatile mode;

void EPFAS_SysInit()
{
  counter = 0;
  mode = 0;
}

void EPFAS_SysNextMode()
{
  mode++;
  if (mode > SYMBOL_COUNT)
  {
    mode = 0;
  }
}

void EPFAS_SysCounterInc()
{
  switch (mode)
  {
    case 1:
      counter++;
      break;

    case 2:
      counter += 10;
      break;

    case 3:
      counter += 100;
      break;
  }
  if (counter > 999)
	  counter %= 1000;
}

void EPFAS_SysCounterStepDown()
{
  if (counter)
	  counter--;
}

int unsigned EPFAS_GetCounter()
{
  return counter;
}

char EPFAS_GetMode()
{
  return mode;
}

